				<div class="content__meta">
                    <div class="content__meta--category">
                        <?php the_category(' '); ?>
                    </div>
                    <span class="content__meta--date">投稿日：<?php the_time('Y年n月j日');?></span>
                    <?php if ( get_the_date() != get_the_modified_date() ) { ?><span class="content__meta--date">更新日：<?php the_modified_date('Y年n月j日');?></span><?php } ?>
                </div>