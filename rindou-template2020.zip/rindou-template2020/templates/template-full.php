<?php
/**
 * Template Name: 全幅、ページタイトルあり
 * Template Post Type: post, page
 *
 */
get_header();?>
<main id="main" class="full-column" role="main">
        <div class="content">
        <?php
        if ( have_posts() ) {
            while ( have_posts() ) {
                the_post();
                the_content();

            }
        }
        ?>
        </div>
</main>
<?php get_footer();?>
