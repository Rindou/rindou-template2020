<?php
/**
 * Template Name: 全幅、ページタイトルあり
 * Template Post Type: post, page
 *
 */
get_header();?>
        <div class="page-content">
        <?php
        if ( have_posts() ) {
            while ( have_posts() ) {
                the_post();
                the_content();

            }
        }
        ?>
        </div>
<?php get_footer();?>
