<?php
/**
 * Template Name: 全幅、ページタイトルなし
 * Template Post Type: post, page
 *
 */
get_header();?>
<main id="main" class="full-column" role="main">
        <div class="content">
        <?php
        if ( have_posts() ) {
            while ( have_posts() ) {
                the_post();
                the_content();

            }
        }
        ?>
        </div>

        <?php
        $next_post = get_next_post(true);
        $prev_post = get_previous_post(true);

        if ( $next_post || $prev_post ) {

            $pagination_classes = '';

            if ( ! $next_post ) {
                $pagination_classes = ' only-one only-prev';
            } elseif ( ! $prev_post ) {
                $pagination_classes = ' only-one only-next';
            }

            ?>
		<div class="container">
	        <div class="single-navigation <?php echo esc_attr( $pagination_classes ); ?>">
	            <?php
	            if ( $prev_post ) {
	                ?>

	                <a class="single-navigation__item--previous" href="<?php echo esc_url( get_permalink( $prev_post->ID ) ); ?>">
	                    <span class="title"><span class="title-inner"><?php echo wp_kses_post( get_the_title( $prev_post->ID ) ); ?></span></span>
	                </a>

	                <?php
	            }

	            if ( $next_post ) {
	                ?>

	                <a class="single-navigation__item--next" href="<?php echo esc_url( get_permalink( $next_post->ID ) ); ?>">
	                        <span class="title"><span class="title-inner"><?php echo wp_kses_post( get_the_title( $next_post->ID ) ); ?></span></span>
	                </a>
	                <?php
	            }
	            ?>
	        </div>
	    </div>
            <?php
        }
        ?>
</main>
<?php get_footer();?>
