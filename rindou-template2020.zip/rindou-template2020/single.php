<?php get_header();?>
<main id="main" class="one-column" role="main">
        <div class="content">
            <?php if ( has_post_thumbnail() ): ?>
            <div class="single-content__eyechatch">
            <?php the_post_thumbnail( 'large', array( 'class' => 'single-content__eyechatch--image' ) ); ?>
            </div>
            <?php endif; ?>
            <?php
            if ( have_posts() ) {
                while ( have_posts() ) {
                    the_post();
                    the_content();

                }
            }
            ?>
        </div>
        <?php if ( (bool) get_the_author_meta( 'description' ) && (bool) get_theme_mod( 'show_author_bio', true ) ) :?>
        <div class="author-box">
            <div class="author-box__profile">
                <p class="author-box__profile--text">この記事を書いた人</p>
                <?php echo get_avatar( get_the_author_meta( 'ID' ), 150 ); ?>
                <p class="author-box__profile--name"><?php the_author_posts_link(); ?></p>
            </div>
            <div class="author-box__introduction">
                <p class="author-box__introduction--text"><?php the_author_meta(  'description' ); ?></p>
                <?php if( get_the_author_meta('user_url') != "" || get_the_author_meta('facebook') != "" || get_the_author_meta('twitter') != "" || get_the_author_meta('instagram') != "" || get_the_author_meta('youtube') != "" ): ?><ul class="author-box__introduction--sns"><?php endif; ?>
                    <?php if(get_the_author_meta('user_url') != ""): ?>
                    <li class="author-box__introduction--sns-item"><a href="<?php the_author_meta('user_url'); ?>" class="author-box__introduction--sns-item-link" target="_blank" rel="noopener"><i class="fas fa-globe fa-fw"></i>ホームページ</a></li>
                    <?php endif; ?>
                    <?php if(get_the_author_meta('facebook') != ""): ?>
                    <li class="author-box__introduction--sns-item"><a href="<?php the_author_meta('facebook'); ?>" class="author-box__introduction--sns-item-link" target="_blank" rel="noopener"><i class="fab fa-facebook-f fa-fw"></i>Facebook</a></li>
                    <?php endif; ?>
                    <?php if(get_the_author_meta('twitter') != ""): ?>
                    <li class="author-box__introduction--sns-item"><a href="<?php the_author_meta('twitter'); ?>" class="author-box__introduction--sns-item-link" target="_blank" rel="noopener"><i class="fab fa-twitter fa-fw"></i>Twitter</a></li>
                    <?php endif; ?>
                    <?php if(get_the_author_meta('instagram') != ""): ?>
                    <li class="author-box__introduction--sns-item"><a href="<?php the_author_meta('instagram'); ?>" class="author-box__introduction--sns-item-link" target="_blank" rel="noopener"><i class="fab fa-instagram fa-fw"></i>Instagram</a></li>
                    <?php endif; ?>
                    <?php if(get_the_author_meta('youtube') != ""): ?>
                    <li class="author-box__introduction--sns-item"><a href="<?php the_author_meta('youtube'); ?>" class="author-box__introduction--sns-item-link" target="_blank" rel="noopener"><i class="fab fa-youtube fa-fw"></i>YouTube</a></li>
                    <?php endif; ?>
                <?php if( get_the_author_meta('user_url') != "" || get_the_author_meta('facebook') != "" || get_the_author_meta('twitter') != "" || get_the_author_meta('instagram') != "" || get_the_author_meta('youtube') != "" ): ?></ul><?php endif; ?>
            </div>
        </div>
        <?php endif; ?>

        <?php comments_template(); ?>

        <?php
        $next_post = get_next_post();
        $prev_post = get_previous_post();

        if ( $next_post || $prev_post ) {

            $pagination_classes = '';

            if ( ! $next_post ) {
                $pagination_classes = ' only-one only-prev';
            } elseif ( ! $prev_post ) {
                $pagination_classes = ' only-one only-next';
            }

            ?>

        <div class="single-navigation <?php echo esc_attr( $pagination_classes ); ?>">
            <?php
            if ( $prev_post ) {
                ?>

                <a class="single-navigation__item--previous" href="<?php echo esc_url( get_permalink( $prev_post->ID ) ); ?>">
                    <span class="title"><span class="title-inner"><?php echo wp_kses_post( get_the_title( $prev_post->ID ) ); ?></span></span>
                </a>

                <?php
            }

            if ( $next_post ) {
                ?>

                <a class="single-navigation__item--next" href="<?php echo esc_url( get_permalink( $next_post->ID ) ); ?>">
                        <span class="title"><span class="title-inner"><?php echo wp_kses_post( get_the_title( $next_post->ID ) ); ?></span></span>
                </a>
                <?php
            }
            ?>
        </div>
            <?php
        }
        ?>
      </main>
<?php get_footer();?>
