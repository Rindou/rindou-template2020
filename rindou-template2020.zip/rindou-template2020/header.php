<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?> id="body">
    <header id="header-fixed">
        <div class="header">
            <div class="header-logo">
                <p class="header-logo__subtitle logo-subtitle"><?php bloginfo( 'description' ); ?></p>
                    <?php
                    the_custom_logo();
                    if (!has_custom_logo()) { ?>
                        <a href="<?php bloginfo( 'url' ); ?>" class="header-logo__link"><?php bloginfo('name');?></a>
                    <?php }
                    ?>
            </div>
            <nav id="site-navigation" class="main-navigation" role="navigation">
                <ul class="main-navigation__menu">
                    <?php
                    if ( has_nav_menu( 'primary' ) ) {

                        wp_nav_menu(
                            array(
                                'container'  => '',
                                'items_wrap' => '%3$s',
                                'theme_location' => 'primary',
                            )
                        );

                    } elseif ( ! has_nav_menu( 'expanded' ) ) {

                        wp_list_pages(
                            array(
                                'match_menu_classes' => true,
                                'show_sub_menu_icons' => true,
                                'title_li' => false,
                            )
                        );

                    }
                    ?>
                    <?php $author = 1; if(get_the_author_meta('contact_url',$author) != ""): ?><li><a href="<?php the_author_meta('contact_url',$author); ?>" class="main-navigation__menu__item--contact">お問い合わせ</a></li><?php endif; ?>
                    <li><span id="js-hamburger-close" class="main-navigation__menu__item--close">閉じる</span></li>
                </ul>
            </nav>
            <div class="hamburger" id="js-hamburger">
                <span class="hamburger__line hamburger__line--1"></span>
                <span class="hamburger__line hamburger__line--2"></span>
                <span class="hamburger__line hamburger__line--3"></span>
            </div>
            <div class="hamburger-bg" id="js-hamburger-bg"></div>
        </div>
    </header>
    <?php
     $page = get_post( get_the_ID() );
     $slug = $page->post_name;
     $title = $page->post_title;
     $cat = get_queried_object();
    $cat_name = $cat -> name;
    $cat_slug = $cat -> slug;

     $page_title    = '';
     $page_subtitle = '';


    if ( is_search() ) {
        global $wp_query;

        $page_title = sprintf(
            '「' . get_search_query() . '」の検索結果'
        );

        if ( $wp_query->found_posts ) {
            $page_subtitle = sprintf(
                 '%s件の記事が見つかりました',
                number_format_i18n( $wp_query->found_posts )
            );
        } else {
            $page_subtitle = '記事が見つかりませんでした。';
        }
    } elseif ( is_category() ) {
        $page_title    = $cat_name;
        $page_subtitle = $cat_slug;
    } elseif ( is_archive() ) {
        $page_title    = get_the_archive_title();
        $page_subtitle = get_the_archive_description();
    } elseif ( is_page() ) {
        $page_title    = $title;
        $page_subtitle = $slug;
    } elseif ( is_404() ) {
        $page_title    = 'ページが見つかりません';
        $page_subtitle = 'Not Found';
    } elseif ( is_home() ) {
      $page_title    = '記事一覧';
      $page_subtitle = 'Blog List';
    }
    ?>
<?php if(!is_page_template( 'templates/template-cover.php' )): ?>
      <?php if(is_single()):?>
        <div class="article-header">
            <div class="article-header__item one-column">
                <h1 class="article-header__title"><?php the_title();?></h1>
                <?php get_template_part( 'template-parts/content-meta' );?>
            </div>
        </div>
      <?php else:?>
        <div class="article-header">
          <div class="article-header__item <?php if(is_page_template( 'templates/template-full.php' )): ?>container<?php else:?>one-column<?php endif;?>">
          <h1 class="article-header__title"><?php echo $page_title; ?></h1>
          <?php if ( $page_subtitle ): ?><div class="article-header__subtitle"><?php echo $page_subtitle; ?></div>
          <?php endif; ?>
          </div>
        </div>
    <?php endif;?>
<?php endif;?>
    <?php if ( is_plugin_active( 'breadcrumb-navxt/breadcrumb-navxt.php' ) ) : ?>
    <?php if(!is_page()):?>
      <div class="one-column">
        <div class="breadcrumb-list">
        <?php if( is_front_page() && is_home() ): ?>
        <?php else:?>
            <?php
                if(function_exists('bcn_display'))
                {
                    bcn_display();
                }
            ?>
        <?php endif;?>
        </div>
      </div>
    <?php endif;?>
    <?php endif;?>
    <main id="main" class="<?php if(is_single()):?>single-content <?php endif;?><?php if(is_page()):?>single-content <?php endif;?><?php if(is_page_template( 'templates/template-cover.php' )): ?>full-column<?php elseif(is_page_template( 'templates/template-full.php' )): ?>full-column<?php else:?>one-column<?php endif;?>" role="main">
