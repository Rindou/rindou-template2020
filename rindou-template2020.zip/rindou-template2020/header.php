<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?> id="body">
    <header id="header-fixed">
        <div class="header">
            <div class="header-logo">
                <p class="header-logo__subtitle logo-subtitle"><?php bloginfo( 'description' ); ?></p>
                    <?php 
                    the_custom_logo();
                    if (!has_custom_logo()) { ?>
                        <a href="<?php bloginfo( 'url' ); ?>" class="header-logo__link"><?php bloginfo('name');?></a>
                    <?php }
                    ?>
            </div>
            <nav id="site-navigation" class="main-navigation" role="navigation">
                <ul class="main-navigation__menu">
                    <?php
                    if ( has_nav_menu( 'primary' ) ) {

                        wp_nav_menu(
                            array(
                                'container'  => '',
                                'items_wrap' => '%3$s',
                                'theme_location' => 'primary',
                            )
                        );

                    } elseif ( ! has_nav_menu( 'expanded' ) ) {

                        wp_list_pages(
                            array(
                                'match_menu_classes' => true,
                                'show_sub_menu_icons' => true,
                                'title_li' => false,
                            )
                        );

                    }
                    ?>
                    <?php $author = 1; if(get_the_author_meta('contact_url',$author) != ""): ?><li><a href="<?php the_author_meta('contact_url',$author); ?>" class="main-navigation__menu__item--contact">お問い合わせ</a></li><?php endif; ?>
                    <li><span id="js-hamburger-close" class="main-navigation__menu__item--close">閉じる</span></li>
                </ul>
            </nav>
            <div class="hamburger" id="js-hamburger">
                <span class="hamburger__line hamburger__line--1"></span>
                <span class="hamburger__line hamburger__line--2"></span>
                <span class="hamburger__line hamburger__line--3"></span>
            </div>
            <div class="hamburger-bg" id="js-hamburger-bg"></div>
        </div>
    </header>