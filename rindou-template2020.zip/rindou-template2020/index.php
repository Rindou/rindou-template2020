<?php get_header();?>
    <div class="article-header">
        <div class="article-header__item">
        <?php

        $archive_title    = '';
        $archive_subtitle = '';

        if ( is_search() ) {
            global $wp_query;

            $archive_title = sprintf(
                '%1$s %2$s',
                '<span class="color-accent">' . __( 'Search:', 'twentytwenty' ) . '</span>',
                '&ldquo;' . get_search_query() . '&rdquo;'
            );

            if ( $wp_query->found_posts ) {
                $archive_subtitle = sprintf(
                    /* translators: %s: Number of search results */
                    _n(
                        'We found %s result for your search.',
                        'We found %s results for your search.',
                        $wp_query->found_posts,
                        'twentytwenty'
                    ),
                    number_format_i18n( $wp_query->found_posts )
                );
            } else {
                $archive_subtitle = __( 'We could not find any results for your search. You can give it another try through the search form below.', 'twentytwenty' );
            }
        } elseif ( ! is_home() ) {
            $archive_title    = get_the_archive_title();
            $archive_subtitle = get_the_archive_description();
        }
        if ( is_home() ) {
            echo '<h1 class="article-header__title">ブログ</h1>';
        }

        if ( $archive_title || $archive_subtitle ) {
            ?>
                    <?php if ( $archive_title ) { ?>
                        <h1 class="article-header__title"><?php echo wp_kses_post( $archive_title ); ?></h1>
                    <?php } ?>

                    <?php if ( $archive_subtitle ) { ?>
                        <div class="article-header__subtitle"><?php echo wp_kses_post( wpautop( $archive_subtitle ) ); ?></div>
                    <?php } ?>
        <?php } ?>
        </div>
    </div>
    <div class="breadcrumb-list">
<?php if( is_front_page() && is_home() ): ?>
<?php else:?>
    <?php 
        if(function_exists('bcn_display'))
        {
            bcn_display();
        }
    ?>
<?php endif;?>
    </div>
    <main id="main" class="site-main one-column" role="main">

    <?php 
    if ( have_posts() ) {
        while ( have_posts() ) {
            the_post(); ?>
        <div class="article-list">
            <div class="article-list__image">
            <?php if ( has_post_thumbnail() ) { ?>
                    <a href="<?php the_permalink();?>" class="article-list__link"><?php the_post_thumbnail( 'large', array( 'class' => 'article-list__link--image' )  ); ?></a>
                <?php } else {?>
                    <a href="<?php the_permalink();?>" class="article-list__link"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/noimage.png" class="article-list__link--image"></a>
            <?php } ?>
            </div>
            <div class="article-list__content">
                <h2 class="article-list__title"><a href="<?php the_permalink();?>" class="article-list__title-link"><?php the_title();?></a></h2>
                <div class="article-list__text">
                    <p><a href="<?php the_permalink();?>" class="article-list__text-link"><?php the_excerpt();?></a></p>
                </div>
                <?php get_template_part( 'template-parts/content-meta' );?>
            </div>
        </div>
    <?php    }
    }
    ?>

        <nav class="page-navigation" role="navigation" aria-label="投稿">
            <?php wp_pagenavi(); ?>
        </nav>
    </main>
<?php get_footer();?>