<?php get_header();?>
    <div class="article-header">
        <div class="article-header__item">
            <h1 class="article-header__title"><?php the_title();?></h1>
        </div>
    </div>
    <main id="main" class="one-column" role="main">
        <div class="page-content">
        <?php 
        if ( have_posts() ) {
            while ( have_posts() ) {
                the_post();
                the_content();
            
            }
        }
        ?>
        </div>

    </main>
<?php get_footer();?>