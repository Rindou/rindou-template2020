//ハンバーガー
function toggleNav() {
  var body = document.body;
  var hamburger = document.getElementById('js-hamburger');
  var blackBg = document.getElementById('js-hamburger-bg');
  var hamburgerClose = document.getElementById('js-hamburger-close');

  hamburger.addEventListener('click', function() {
    body.classList.toggle('nav-open');
  });
  blackBg.addEventListener('click', function() {
    body.classList.remove('nav-open');
  });
  hamburgerClose.addEventListener('click', function() {
    body.classList.remove('nav-open');
  });
}
toggleNav();

//固定ヘッダー
function fixedHeader() {

  const target     = document.getElementById('header-fixed'),
        height     = document.getElementById('header-fixed').clientHeight;
  let offset       = 0,
      lastPosition = 0,
      ticking      = false;
      
  function onScroll() {
    if (lastPosition > height) {
      if (lastPosition > offset) {
        target.classList.add('head-animation');
      } else {
        target.classList.remove('head-animation');
      }
      offset = lastPosition;
    }
  }
  
  window.addEventListener('scroll', function(e) {
    lastPosition = window.scrollY;
    if (!ticking) {
      window.requestAnimationFrame(function() {
        onScroll(lastPosition);
        ticking = false;
      });
      ticking = true;
    }
  });
}
fixedHeader();

//固定ヘッダーの高さ
function getHeight(){
  var body = document.getElementById("body");
  var header = document.getElementById("header-fixed");
  var h = header.getBoundingClientRect().height + 'px';
  body.style.marginTop = h;
};
getHeight();