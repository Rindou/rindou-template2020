<?php

//WordPressセットアップ
//--------------------------------------------------------------------
function rindou_theme_support() {

	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'post-thumbnails' );
	set_post_thumbnail_size( 1200, 9999 );
	add_theme_support( 'title-tag' );
    add_theme_support('custom-logo');
    add_theme_support( 'editor-styles' );
	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'script',
			'style',
		)
	);
}
add_action( 'after_setup_theme', 'rindou_theme_support' );


//スタイルシート、JS読み込み
//--------------------------------------------------------------------
function rn_scripts() {
    wp_enqueue_style( 'rn-css-sanitize', get_template_directory_uri().'/assets/css/sanitize.css' );
    wp_enqueue_style( 'rn-css-style', get_template_directory_uri().'/assets/css/style.css' );
    wp_enqueue_style( 'rn-css-customize', get_template_directory_uri().'/assets/css/customize.css' );
    wp_enqueue_style( 'rn-css-fontawesome', get_template_directory_uri().'/assets/css/fontawesome-all.css' );
    wp_enqueue_script( 'rn-js-rindou', get_template_directory_uri().'/assets/js/rindou.js', array(), '20200713', true );


wp_enqueue_script('jquery');

    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'rn_scripts' );

add_editor_style(get_template_directory_uri().'/assets/css/editor-style.css');


//抜粋
//--------------------------------------------------------------------
function rindou_change_excerpt_length( $length ) {
  return 100; 
}
add_filter( 'excerpt_length', 'rindou_change_excerpt_length', 999 );

function rindou_change_excerpt_more( $more ) {
  $html = '&thinsp;...&thinsp;<span class="article-list__text-more">続きを読む</span>';
  return $html;
}

add_filter( 'excerpt_more', 'rindou_change_excerpt_more' );


//カスタムメニュー
//--------------------------------------------------------------------
function rindou_menus() {

	$locations = array(
		'primary'  => __( 'グローバルメニュー' ),
		'footer'   => __( 'フッターメニュー' ),
	);

	register_nav_menus( $locations );
}

add_action( 'init', 'rindou_menus' );

// 「メールアドレスが公開されることはありません。 * が付いている欄は必須項目です」の文言を変更
//--------------------------------------------------------------------
add_filter('comment_form_defaults', 'change_comment_email_notes');
 
function change_comment_email_notes( $defaults ) {
 
    $defaults['comment_notes_before'] = '<p class="comment-notes">メールアドレスが公開されることはありません。</p>';
 
    return $defaults;
}

//ウィジェット
//--------------------------------------------------------------------
function rindou_sidebar_registration() {

	$shared_args = array(
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
		'before_widget' => '<aside class="footer-aside__list widget %2$s">',
		'after_widget'  => '</aside>',
	);

	register_sidebar(
		array_merge(
			$shared_args,
			array(
				'name'        => __( 'ウィジェット'),
				'id'          => 'sidebar-1',
				'description' => __( '記事の下に表示されます。' ),
			)
		)
	);


}

add_action( 'widgets_init', 'rindou_sidebar_registration' );


//ウィジェット年別アーカイブ
//--------------------------------------------------------------------
class Widget_Archives2 extends WP_Widget {
 
    function __construct() {
        $widget_ops = array('classname' => 'widget_archives2', 'description' => 'サイトの投稿の年別/月別アーカイブ' );
        parent::__construct('archives2', 'アーカイブ （年別/月別）', $widget_ops);
    }
 
    function widget( $args, $instance ) {
        extract($args);
        $c = ! empty( $instance['count'] ) ? '1' : '0';
        $title = apply_filters('widget_title', empty($instance['title']) ? __('Archives') : $instance['title'], $instance, $this->id_base);
 
        echo $before_widget;
        if ( $title )
            echo $before_title . $title . $after_title;
 
        $this->get_archives(apply_filters('widget_archives2_args', array('show_post_count' => $c)));
 
        echo $after_widget;
    }
 
    function update( $new_instance, $old_instance ) {
        $instance = $old_instance;
        $new_instance = wp_parse_args( (array) $new_instance, array( 'title' => '', 'count' => 0) );
        $instance['title'] = strip_tags($new_instance['title']);
        $instance['count'] = $new_instance['count'] ? 1 : 0;
 
        return $instance;
    }
 
    function form( $instance ) {
        $instance = wp_parse_args( (array) $instance, array( 'title' => '', 'count' => 0) );
        $title = strip_tags($instance['title']);
        $count = $instance['count'] ? 'checked="checked"' : '';
?>
        <p><label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:'); ?></label>
        <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></p>
        <p>
            <input class="checkbox" type="checkbox" <?php echo $count; ?> id="<?php echo $this->get_field_id('count'); ?>" name="<?php echo $this->get_field_name('count'); ?>" />
            <label for="<?php echo $this->get_field_id('count'); ?>"><?php _e('Show post counts'); ?></label>
        </p>
<?php
    }
 
    function get_archives($args = '') {
 
        $defaults = array(
            'limit' => '',
            'before' => '',
            'after' => '',
            'show_post_count' => false,
            'echo' => 1,
            'order' => 'ASC',
        );
 
        $r = wp_parse_args( $args, $defaults );
        extract( $r, EXTR_SKIP );
 
        $arcresults = $this->get_monthly_archives_data($r);
 
        $output = $this->build_html($r, $arcresults);
 
        if ( $echo )
            echo $output;
        else
            return $output;
    }
 
    function get_monthly_archives_data($args) {
        global $wpdb;
        extract( $args, EXTR_SKIP );
 
        if ( '' != $limit ) {
            $limit = absint($limit);
            $limit = ' LIMIT '.$limit;
        }
 
        $order = strtoupper( $order );
        if ( $order !== 'ASC' )
            $order = 'DESC';
 
        //filters
        $where = apply_filters( 'getarchives2_where', "WHERE post_type = 'post' AND post_status = 'publish'", $args );
        $join = apply_filters( 'getarchives2_join', '', $args );
 
        $query = "SELECT YEAR(post_date) AS `year`, MONTH(post_date) AS `month`, count(ID) as posts FROM $wpdb->posts $join $where GROUP BY YEAR(post_date), MONTH(post_date) ORDER BY post_date $order $limit";
        $key = md5($query);
        $cache = wp_cache_get( 'get_archives2' , 'general');
        if ( !isset( $cache[ $key ] ) ) {
            $arcresults = $wpdb->get_results($query);
            $cache[ $key ] = $arcresults;
            wp_cache_set( 'get_archives2', $cache, 'general' );
        } else {
            $arcresults = $cache[ $key ];
        }
 
        return $arcresults;
    }
 
    function build_html($args, $arcresults) {
        extract( $args, EXTR_SKIP );
 
        if ( !$arcresults )
            return '';
 
        $cur_year = -1;
        $afterafter = $after;
 
        $output = '<ul class="yearArchiveList">'; // (1)
        foreach ( (array) $arcresults as $arcresult ) {
            if ( $cur_year != $arcresult->year ) {
                if ( $cur_year > 0 ) {
                    $output .= "</ul>"; // (/3)
                    $output .= "</li>\n"; // (/2)
                }
                $output .= '<li><span class="year">'  . $arcresult->year . "年</span>"; // (2)
                $output .= '<ul class="eachYear">'; // (3)
 
                $cur_year = $arcresult->year;
            }
 
            if ( $show_post_count )
                $after = " ({$arcresult->posts}){$afterafter}";
 
            $output .= '<li class="singleList">' . $this->get_archives_link($arcresult->year, $arcresult->month, $before, $after) . "</li>\n";
        }
        $output .= "</ul>"; // (/3)
        $output .= "</li>\n"; // (/2)
        $output .= "</ul>\n"; // (/1)
 
        return $output;
    }
 
    function get_archives_link($year, $month, $before = '', $after = '') {
        global $wp_locale;
 
        $url = get_month_link($year, $month);
        $url = esc_url($url);
 
        $text = $wp_locale->get_month($month);
        $text = wptexturize($text);
 
        $title_text = sprintf(__('%1$s %2$d'), $wp_locale->get_month($month), $year);
        $title_text = esc_attr($title_text);
 
        $link_html = "$before<a href='$url' title='$title_text'>$text</a>$after";
        $link_html = apply_filters( 'get_archives2_link', $link_html );
 
        return $link_html;
    }
}

register_widget("Widget_Archives2");

//アーカイブの見出し
//--------------------------------------------------------------------
add_filter( 'get_the_archive_title', function ($title) {
    if (is_category()) {
        $title = single_cat_title('',false);
    } elseif (is_tag()) {
        $title = single_tag_title('',false);
	} elseif (is_tax()) {
	    $title = single_term_title('',false);
	} elseif (is_post_type_archive() ){
		$title = post_type_archive_title('',false);
	} elseif (is_date()) {
	    $title = get_the_time('Y年n月');
	} elseif (is_search()) {
	    $title = '検索結果：'.esc_html( get_search_query(false) );
	} elseif (is_404()) {
	    $title = '「404」ページが見つかりません';
	} elseif ( is_author() ) {
            $title =  get_the_author();
        } else {

	}
    return $title;
});


//著者情報のSNS追加
//--------------------------------------------------------------------
function update_profile_fields( $contactmethods ) {
    //項目の追加
    $contactmethods['facebook'] = 'Facebook';
    $contactmethods['twitter'] = 'Twitter';
    $contactmethods['instagram'] = 'Instagram';
    $contactmethods['youtube'] = 'YouTube';
    $contactmethods['shop_address'] = '住所';
    $contactmethods['shop_tell'] = '電話番号';
    $contactmethods['business_hours'] = '受付時間';
    $contactmethods['contact_url'] = 'お問い合わせURL';
     
    return $contactmethods;
}
add_filter('user_contactmethods','update_profile_fields',10,1);


//入力フィールド用
function add_user_profile_fields($bool) {
  global $profileuser;
 
  //テキストエリア
  echo '<tr><th><label for="free_input">住所の下の一言</label></th><td><textarea name="free_input" rows="3" cols="30">'.esc_html($profileuser->free_input).'</textarea></td></tr>';
 
 
  return $bool;
}
add_action('show_password_fields', 'add_user_profile_fields');
 
//追加した独自項目の更新
function update_user_profile_fields($user_id, $old_user_data) {
  //テキストエリアを更新
  if(isset($_POST['free_input'])) {
    update_user_meta($user_id, 'free_input', $_POST['free_input'], $old_user_data->t_area);
  }
}
add_action('profile_update', 'update_user_profile_fields', 10, 2);


//内部ブログカード
//--------------------------------------------------------------------
remove_action('embed_head', 'print_embed_styles');

//外部ブログカード(WordPressサイト01)
//--------------------------------------------------------------------
if ( !function_exists( 'show_Linkcard_wp1' ) ):
function show_Linkcard_wp1($the_content) {
if(is_single()) {

	$myurl = get_site_url();

    $regex = "/^<figure class=[\"|']wp\-block\-embed\-wordpress.*[\"|'].*><div class=[\"|']wp\-block\-embed__wrapper[\"|\']>[\s\S].*<\/iframe>[\s\S]<\/div><\/figure>/im";

    $result = preg_match_all($regex, $the_content, $matches);
    

    $i = 0;
    foreach ($matches[0] as $match ) {
        preg_match_all('/<a[^>]+href=([\'"])(?<href>.+?)\1[^>]*>/i', $match, $url01);

        if (!empty($url01)) {
            $url = $url01['href'][0];
        }

        if ( strpos( $url, $myurl ) !== false ) {
        	continue;
    	}
    
        //OGP情報を取得
        require_once 'lib/OpenGraph.php';
        $graph = OpenGraph::fetch($url);

        //OGPタグからタイトルを取得
        $Link_title = $graph->title;
        if(!empty($title)){
            $Link_title = $title;//title=""の入力がある場合はそちらを優先
        }
            
        //OGPタグからdescriptionを取得（抜粋文として利用）
        $Link_description = wp_trim_words($graph->description, 100, ' …' );//文字数は任意で変更
        if(!empty($excerpt)){
            $Link_description = $excerpt;//値を取得できない時は手動でexcerpt=""を入力
        }
        
        //OGPタグから画像を取得
        $Link_image = $graph->image;
        if(!empty($Link_image)){
            //画像を表示
            $Link_img_html = '<div class="blogcard_thumbnail"><a href="'. $url .'" target="_blank" rel="noopener"><img src="'. $Link_image .'" /></a></div>';
        }
        else {
            $Link_img_html = '';
        }
        
        //ファビコンを取得（GoogleのAPIでスクレイピング）
        $host = parse_url($url)['host'];
        $searchFavcon = 'https://www.google.com/s2/favicons?domain='.$host;
        if($searchFavcon){
            $favicon = '<img class="favicon" src="'.$searchFavcon.'">';
        }
            
        //外部リンク用ブログカードHTML出力
        ${'sc_Linkcard'.$i} .='
        <div class="blogcard">
         '. $Link_img_html .'
         <div class="blogcard_content">
          <div class="blogcard_title"><a href="'. $url .'" target="_blank" rel="noopener">'. $Link_title .'</a></div>
          <div class="blogcard_excerpt"><a href="'. $url .'" target="_blank" rel="noopener">'. $Link_description .'</a></div>
          <div class="blogcard_link"><a href="'. $url .'" target="_blank" rel="noopener">'. $favicon .' '. $url .'</a></div>
         </div>
        </div>';



        $the_content = preg_replace('{^'.preg_quote($match, '{}').'}im', ${'sc_Linkcard'.$i}, $the_content,1);
        
        $i++;
    }
    return $the_content;

} else {
    return $the_content;
}
}

endif;
add_filter('the_content', 'show_Linkcard_wp1');

//外部ブログカード(WordPressサイト02)
//--------------------------------------------------------------------
if ( !function_exists( 'show_Linkcard_wp2' ) ):
function show_Linkcard_wp2($the_content) {
if(is_single()) {

	$myurl = get_site_url();

    $regex = "/^<figure class=[\"|']wp\-block\-embed\-wordpress.*[\"|'].*><div class=[\"|']wp\-block\-embed__wrapper[\"|\']>.*[\s\S](https?|ftp)(:\/\/[-_.!~*\'()a-zA-Z0-9;\/?:\@&=+\$,%#]+)$[\s\S].*<\/div><\/figure>/im";

    $result = preg_match_all($regex, $the_content, $matches);

    $i = 0;
    foreach ($matches[0] as $match ) {
        $url01 = strip_tags($match);
        $url = trim($url01);

        if ( strpos( $url, $myurl ) !== false ) {
        	continue;
    	}

        //OGP情報を取得
        require_once 'lib/OpenGraph.php';
        $graph = OpenGraph::fetch($url);

        //OGPタグからタイトルを取得
        $Link_title = $graph->title;
        if(!empty($title)){
            $Link_title = $title;//title=""の入力がある場合はそちらを優先
        }
            
        //OGPタグからdescriptionを取得（抜粋文として利用）
        $Link_description = wp_trim_words($graph->description, 100, ' …' );//文字数は任意で変更
        if(!empty($excerpt)){
            $Link_description = $excerpt;//値を取得できない時は手動でexcerpt=""を入力
        }
        
        //OGPタグから画像を取得
        $Link_image = $graph->image;
        if(!empty($Link_image)){
            //画像を表示
            $Link_img_html = '<div class="blogcard_thumbnail"><a href="'. $url .'" target="_blank" rel="noopener"><img src="'. $Link_image .'" /></a></div>';
        }
        else {
            $Link_img_html = '';
        }
        
        //ファビコンを取得（GoogleのAPIでスクレイピング）
        $host = parse_url($url)['host'];
        $searchFavcon = 'https://www.google.com/s2/favicons?domain='.$host;
        if($searchFavcon){
            $favicon = '<img class="favicon" src="'.$searchFavcon.'">';
        }
            
        //外部リンク用ブログカードHTML出力
        ${'sc_Linkcard'.$i} .='
        <div class="blogcard">
         '. $Link_img_html .'
         <div class="blogcard_content">
          <div class="blogcard_title"><a href="'. $url .'" target="_blank" rel="noopener">'. $Link_title .'</a></div>
          <div class="blogcard_excerpt"><a href="'. $url .'" target="_blank" rel="noopener">'. $Link_description .'</a></div>
          <div class="blogcard_link"><a href="'. $url .'" target="_blank" rel="noopener">'. $favicon .' '. $url .'</a></div>
         </div>
        </div>';



        $the_content = preg_replace('{^'.preg_quote($match, '{}').'}im', ${'sc_Linkcard'.$i}, $the_content,1);
        
        $i++;
    }
    return $the_content;

} else {
    return $the_content;
}
}

endif;
add_filter('the_content', 'show_Linkcard_wp2');


//外部ブログカード
//--------------------------------------------------------------------
if ( !function_exists( 'show_Linkcard_out' ) ):
function show_Linkcard_out($the_content) {
if(is_single()) {

    $regex = "/^<figure class=[\"|']wp\-block\-embed[\"|\'].*>[\s\S].*[\s\S].*<\/figure>/im";

	$result = preg_match_all($regex, $the_content, $matches);


	$i = 0;
	foreach ($matches[0] as $match ) {
        $url01 = strip_tags($match);
        $url = trim($url01);
	
		//OGP情報を取得
		require_once 'lib/OpenGraph.php';
		$graph = OpenGraph::fetch($url);

		//OGPタグからタイトルを取得
		$Link_title = $graph->title;
		if(!empty($title)){
			$Link_title = $title;//title=""の入力がある場合はそちらを優先
		}

        //OGPタグからdescriptionを取得（抜粋文として利用）
        $Link_description = wp_trim_words($graph->description, 100, ' …' );//文字数は任意で変更
        if(!empty($excerpt)){
            $Link_description = $excerpt;//値を取得できない時は手動でexcerpt=""を入力
        }
        
        //OGPタグから画像を取得
        $Link_image = $graph->image;
        if(!empty($Link_image)){
            //画像を表示
            $Link_img_html = '<div class="blogcard_thumbnail"><a href="'. $url .'" target="_blank" rel="noopener"><img src="'. $Link_image .'" /></a></div>';
        }
        else {
            $Link_img_html = '';
        }
        
		//ファビコンを取得（GoogleのAPIでスクレイピング）
		$host = parse_url($url)['host'];
		$searchFavcon = 'https://www.google.com/s2/favicons?domain='.$host;
		if($searchFavcon){
			$favicon = '<img class="favicon" src="'.$searchFavcon.'">';
		}
			
		//外部リンク用ブログカードHTML出力
		${'sc_Linkcard'.$i} .='
		<div class="blogcard">
		 '. $Link_img_html .'
		 <div class="blogcard_content">
		  <div class="blogcard_title"><a href="'. $url .'" target="_blank" rel="noopener">'. $Link_title .'</a></div>
		  <div class="blogcard_excerpt"><a href="'. $url .'" target="_blank" rel="noopener">'. $Link_description .'</a></div>
		  <div class="blogcard_link"><a href="'. $url .'" target="_blank" rel="noopener">'. $favicon .' '. $url .'</a></div>
		 </div>
		</div>';



		$the_content = preg_replace('{^'.preg_quote($match, '{}').'}im', ${'sc_Linkcard'.$i}, $the_content,1);
		
		$i++;
	}
	return $the_content;

} else {
	return $the_content;
}
}

endif;
add_filter('the_content', 'show_Linkcard_out');
